<?php

	 include_once "koneksi.php";

	 class brg{}

	 $nama = $_POST["nama"];
	 $barcode = $_POST["barcode"];
	 $harga = $_POST["harga"];
	 $stok = $_POST["stok"];

	 if ((empty($barcode))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom barcode tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($nama))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom nama tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($harga))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom harga tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($stok))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom stok tidak boleh kosong";
	 	die(json_encode($response));
	 } else {
		 if (!empty($barcode)){
		 	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM barang WHERE barcode='".$barcode."'"));

		 	if ($num_rows == 0){
		 		$query = mysqli_query($con, "INSERT INTO barang (id, nama, barcode, harga, stok) VALUES(0,'".$nama."','".$barcode."','".$harga."','".$stok."')");

		 		if ($query){
		 			$response = new brg();
		 			$response->success = 1;
		 			$response->message = "Barang berhasil ditambahkan.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new brg();
		 			$response->success = 0;
		 			$response->message = "Barang sudah ada";
		 			die(json_encode($response));
		 		}
		 	} else {
		 		$response = new brg();
		 		$response->success = 0;
		 		$response->message = "Barang sudah ada";
		 		die(json_encode($response));
		 	}
		 }
	 }

	 mysqli_close($con);

?>	