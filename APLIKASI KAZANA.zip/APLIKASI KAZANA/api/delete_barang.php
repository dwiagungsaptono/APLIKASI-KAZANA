<?php

	 include_once "koneksi.php";

	 class brg{}

	 $id = $_POST["id"];

			$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM barang WHERE id='".$id."'"));

		 	if ($num_rows != 0){
		 		$query = mysqli_query($con, "DELETE FROM barang WHERE id='".$id."'");

		 		if ($query){
		 			$response = new brg();
		 			$response->success = 1;
		 			$response->message = "Barang berhasil dihapus.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new brg();
		 			$response->success = 0;
		 			$response->message = "Barang tidak ada";
		 			die(json_encode($response));
		 		}
		 	} else {
		 		$response = new brg();
		 		$response->success = 0;
		 		$response->message = "Barang tidak ada";
		 		die(json_encode($response));
		 	}

	 mysqli_close($con);

?>	