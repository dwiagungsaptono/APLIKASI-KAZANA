<?php

	 include_once "koneksi.php";

	 class brg{}

	 $id = $_POST["id"];
	 $nama = $_POST["nama"];
	 $harga = $_POST["harga"];
	 $stok = $_POST["stok"];
	 
	 //$id = "4";
	 //$nama = "4";
	 //$harga = "4";
	 //$stok = "4";

	 if ((empty($nama))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom nama tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($harga))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom harga tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($stok))) {
	 	$response = new brg();
	 	$response->success = 0;
	 	$response->message = "Kolom stok tidak boleh kosong";
	 	die(json_encode($response));
	 } else {
		 if (!empty($id)){
		 	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM barang WHERE id='".$id."'"));

		 	if ($num_rows != 0){
		 		$query = mysqli_query($con, "UPDATE barang set nama = '".$nama."', harga = '".$harga."', stok = '".$stok."' WHERE id='".$id."'");

		 		if ($query){
		 			$response = new brg();
		 			$response->success = 1;
		 			$response->message = "Barang berhasil diubah.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new brg();
		 			$response->success = 0;
		 			$response->message = "Barang tidak ada";
		 			die(json_encode($response));
		 		}
		 	} else {
		 		$response = new brg();
		 		$response->success = 0;
		 		$response->message = "Barang tidak ada";
		 		die(json_encode($response));
		 	}
		 }
	 }

	 mysqli_close($con);

?>	