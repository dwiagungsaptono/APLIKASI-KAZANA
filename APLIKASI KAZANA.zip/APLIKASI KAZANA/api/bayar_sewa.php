<?php
	include_once "koneksi.php";
	
	class byr{}
	
	$image = $_POST['image'];
	$name = $_POST['name'];
	$kios = $_POST['kios'];
	$id_user = $_POST['id_user'];
	$date = $_POST['date'];
	
	if (empty($name)) { 
		$response = new byr();
		$response->success = 0;
		$response->message = "Kolom nama tidak boleh kosong"; 
		die(json_encode($response));
	}else if ((empty($kios))) {
	 	$response = new byr();
	 	$response->success = 0;
	 	$response->message = "Kolom kios tidak boleh kosong";
	 	die(json_encode($response));
	}else if ((empty($image))) {
	 	$response = new byr();
	 	$response->success = 0;
	 	$response->message = "gambar tidak boleh kosong";
	 	die(json_encode($response));
	} 
	else {
		$random = random_word(20);
		
		$path = "images/".$random.".png";
		
		// sesuiakan ip address laptop/pc atau URL server
		//$actualpath = "http://khazanah.atwebpages.com/android/api/$path";
		$actualpath = $path;
		
		$query = mysqli_query($con, "INSERT INTO transaksi (id_user, nama,kios,tanggal,photo) VALUES ('$id_user','$name','$kios','$date','$actualpath')");
		
		if ($query){
			file_put_contents($path,base64_decode($image));
			
			$response = new byr();
			$response->success = 1;
			$response->message = "Berhasil Upload";
			die(json_encode($response));
		} else{ 
			$response = new byr();
			$response->success = 0;
			$response->message = "Error Upload";
			die(json_encode($response)); 
		}
	}	
	
	// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}

	mysqli_close($con);
	
?>	