<?php

	 include_once "koneksi.php";

	 class brg{}

	 $id = $_POST["id"];
	 
	 if (!empty($id)){
		 	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM transaksi WHERE id='".$id."'"));

		 	if ($num_rows != 0){
		 		$query = mysqli_query($con, "UPDATE transaksi set status = 'Y' WHERE id='".$id."'");

		 		if ($query){
		 			$response = new brg();
		 			$response->success = 1;
		 			$response->message = "Transaksi disetujui.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new brg();
		 			$response->success = 0;
		 			$response->message = "Transaksi tidak ada";
		 			die(json_encode($response));
		 		}
		 	} else {
		 		$response = new brg();
		 		$response->success = 0;
		 		$response->message = "Transaksi tidak ada";
		 		die(json_encode($response));
		 	}
	}

	 mysqli_close($con);

?>	