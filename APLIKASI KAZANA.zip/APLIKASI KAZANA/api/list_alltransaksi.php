<?php
include_once "koneksi.php";

	 //Membuat SQL Query
	$sql = "SELECT * FROM transaksi";
	//Mendapatkan Hasil
	$r = mysqli_query($con,$sql);
	
	//Membuat Array Kosong 
	$result = array();
	
	while($row = mysqli_fetch_array($r)){
		
		//Memasukkan value kedalam Array Kosong yang telah dibuat 
		array_push($result,array(
			"id"=>$row['id'],
			"id_user"=>$row['id_user'],
			"nama"=>$row['nama'],
			"kios" =>$row['kios'],
			"tanggal" =>$row['tanggal'],
			"photo" =>$row['photo'],
			"status" =>$row['status']
		));
	}
	
	//Menampilkan Array dalam Format JSON
	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);

?>