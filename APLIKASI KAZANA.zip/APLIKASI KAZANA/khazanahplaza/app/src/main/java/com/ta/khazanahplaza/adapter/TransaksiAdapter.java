package com.ta.khazanahplaza.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.model.Transaksi;

import java.util.List;

public class TransaksiAdapter extends ArrayAdapter<Transaksi> {

    private List<Transaksi> transaksiList;

    private Context context;

    public TransaksiAdapter(List<Transaksi> transaksiList, Context context) {
        super(context, R.layout.list_transaksi, transaksiList);
        this.transaksiList = transaksiList;
        this.context = context;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);

        View listViewItem = inflater.inflate(R.layout.list_transaksi, null, true);

        TextView txt_id = listViewItem.findViewById(R.id.txt_h_idT);
        TextView txt_kios = listViewItem.findViewById(R.id.txt_h_kios);
        TextView txt_tgl = listViewItem.findViewById(R.id.txt_h_tgl);
        TextView txt_status = listViewItem.findViewById(R.id.txt_h_ket);

        Transaksi transaksiItem = transaksiList.get(position);

        txt_id.setText(transaksiItem.getID());
        txt_kios.setText(transaksiItem.getKios());
        txt_tgl.setText(transaksiItem.getTanggal());
        if (transaksiItem.getStatus().equals("N")){
            txt_status.setText("Belum Lunas");
        }else{
            txt_status.setText("Lunas");
        }

        return listViewItem;
    }
}
