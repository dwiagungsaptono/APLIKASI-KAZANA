package com.ta.khazanahplaza.model;

import java.io.Serializable;

public class Barang implements Serializable {
    String id, nama, barcode, harga, stok;

    public Barang(String id, String nama, String barcode, String harga, String stok ) {
        this.id = id;
        this.nama = nama;
        this.barcode = barcode;
        this.harga = harga;
        this.stok = stok;
    }

    public String getID() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getBarcode() {
        return barcode;
    }

    public String getHarga(){
        return harga;
    }

    public String getStok() {
        return stok;
    }
}
