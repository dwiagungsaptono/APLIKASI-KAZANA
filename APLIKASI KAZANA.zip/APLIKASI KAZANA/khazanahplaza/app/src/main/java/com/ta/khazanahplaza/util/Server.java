package com.ta.khazanahplaza.util;

//Class ini berfungsi mengatur link server sumber data dari web service yang akan digunakan.
//by : Dwi Agung Saptono

public class Server {
    //server
    //public static final String URL = "http://khazanah.atwebpages.com/android/api/";

    //local
    public static final String URL = "http://192.168.1.2/android/api/";
}
