package com.ta.khazanahplaza.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.model.Barang;

import java.util.List;

public class BarangAdapter extends ArrayAdapter<Barang> {
    private List<Barang> barangList;

    private Context context;

    public BarangAdapter(List<Barang> barangList, Context context) {
        super(context, R.layout.list_barang, barangList);
        this.barangList = barangList;
        this.context = context;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);

        View listViewItem = inflater.inflate(R.layout.list_barang, null, true);

        TextView txt_nama = listViewItem.findViewById(R.id.txt_b_name);
        TextView txt_barcode = listViewItem.findViewById(R.id.txt_b_barcode);
        TextView txt_harga = listViewItem.findViewById(R.id.txt_b_price);
        TextView txt_stok = listViewItem.findViewById(R.id.txt_b_stock);
        TextView txt_id = listViewItem.findViewById(R.id.txt_b_id);
        TextView txt_detail = listViewItem.findViewById(R.id.txt_b_detail);

        txt_detail.setVisibility(View.VISIBLE);

        Barang barangItem = barangList.get(position);

        txt_nama.setText(barangItem.getNama());
        txt_barcode.setText(barangItem.getBarcode());
        txt_harga.setText(barangItem.getHarga());
        txt_stok.setText(barangItem.getStok());
        txt_id.setText(barangItem.getID());

        return listViewItem;
    }
}
