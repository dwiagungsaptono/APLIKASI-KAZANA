package com.ta.khazanahplaza.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ta.khazanahplaza.model.Barang;
import com.ta.khazanahplaza.adapter.BarangAdapter;
import com.ta.khazanahplaza.Login;
import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.app.AppController;
import com.ta.khazanahplaza.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BarangActivity extends AppCompatActivity {

    Button btn_tambah, btn_save;
    String id, username, type;
    String nama, barcode, price, stock;
    SwipeRefreshLayout SwipeRefresh;

    SharedPreferences sharedpreferences;

    ProgressDialog pDialog;
    int success;
    ConnectivityManager conMgr;

    private String url = Server.URL + "add_barang.php";
    private String url_list = Server.URL + "list_barang.php";

    private static final String TAG = BarangActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";

    public static final String TAG_ID = "id";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_TYPE = "type";
    public static final String TAG_B_ID = "b_id";
    public static final String TAG_B_NAMA = "b_nama";
    public static final String TAG_B_BARCODE = "b_barcode";
    public static final String TAG_B_HARGA = "b_harga";
    public static final String TAG_B_STOK = "b_stok";

    ListView listView;
    private List<Barang> barangItemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barang);

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }

        btn_tambah = (Button) findViewById(R.id.btn_tambah);
        SwipeRefresh = findViewById(R.id.swipe_refresh);

        // Mengeset properti warna yang berputar pada SwipeRefreshLayout
        SwipeRefresh.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary);

        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id = getIntent().getStringExtra(TAG_ID);
        username = getIntent().getStringExtra(TAG_USERNAME);
        type = getIntent().getStringExtra(TAG_TYPE);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Barang");
        //getSupportActionBar().setSubtitle("sairam");

        listView =  findViewById(R.id.lv_barang);
        barangItemList = new ArrayList<>();


        loadBarang();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), barangItemList.get(i).getBarcode(), Toast.LENGTH_SHORT).show();
                //memanggil activity update
                Intent intent = new Intent(BarangActivity.this, UpdateActivity.class);
                intent.putExtra(TAG_ID, id);
                intent.putExtra(TAG_USERNAME, username);
                intent.putExtra(TAG_TYPE, type);
                intent.putExtra(TAG_B_ID, barangItemList.get(i).getID());
                intent.putExtra(TAG_B_NAMA, barangItemList.get(i).getNama());
                intent.putExtra(TAG_B_BARCODE, barangItemList.get(i).getBarcode());
                intent.putExtra(TAG_B_HARGA, barangItemList.get(i).getHarga());
                intent.putExtra(TAG_B_STOK, barangItemList.get(i).getStok());
                //finish();
                startActivity(intent);
            }
        });

        // Mengeset listener yang akan dijalankan saat layar di refresh/swipe
        SwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Handler digunakan untuk menjalankan jeda selama 5 detik


                   loadBarang();
            }
        });

        btn_tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(BarangActivity.this);

                //Memasang Title / Judul pada Custom Dialog
                dialog.setTitle("Tambah Barang");

                //Memasang Desain Layout untuk Custom Dialog
                dialog.setContentView(R.layout.barang);

                //Memasang Listener / Aksi saat tombol OK di Klik
                Button btn_simpan = dialog.findViewById(R.id.btn_save);
                Button btn_hapus = dialog.findViewById(R.id.btn_delete);
                final EditText ed_nama = dialog.findViewById(R.id.txt_name);
                final EditText ed_barcode = dialog.findViewById(R.id.txt_barcode);
                final EditText ed_price = dialog.findViewById(R.id.txt_price);
                final EditText ed_stock = dialog.findViewById(R.id.txt_stock);

                btn_hapus.setVisibility(View.GONE);
                btn_simpan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nama = ed_nama.getText().toString();
                        barcode = ed_barcode.getText().toString();
                        price = ed_price.getText().toString();
                        stock = ed_stock.getText().toString();

                        if (conMgr.getActiveNetworkInfo() != null
                                && conMgr.getActiveNetworkInfo().isAvailable()
                                && conMgr.getActiveNetworkInfo().isConnected()) {
                            addBarang(nama, barcode, price, stock);
                            dialog.dismiss();

                        } else {
                            Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                dialog.show();
            }
        });

    }

    private void loadBarang() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Memuat ...");
        showDialog();
        barangItemList.clear();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_list,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideDialog();
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray barangArray = obj.getJSONArray("result");

                            for (int i = 0; i < barangArray.length(); i++) {

                                JSONObject barangObject = barangArray.getJSONObject(i);


                                Barang barangItem = new Barang(barangObject.getString("id"),
                                        barangObject.getString("nama"),
                                        barangObject.getString("barcode"),
                                        barangObject.getString("harga"),
                                        barangObject.getString("stok"));

                                barangItemList.add(barangItem);
                            }

                            BarangAdapter adapter = new BarangAdapter(barangItemList, getApplicationContext());

                            listView.setAdapter(adapter);
                            // Berhenti berputar/refreshing
                            SwipeRefresh.setRefreshing(false);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        hideDialog();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void addBarang(final String nama, final String barcode, final String harga, final String stok) {
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Menambahkan ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Add Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1) {

                        Log.e("Successfully Added!", jObj.toString());

                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                        loadBarang();

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("nama", nama);
                params.put("barcode", barcode);
                params.put("harga", harga);
                params.put("stok", stok);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}