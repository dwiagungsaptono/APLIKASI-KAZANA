package com.ta.khazanahplaza.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ta.khazanahplaza.model.Barang;
import com.ta.khazanahplaza.adapter.CheckAdapter;
import com.ta.khazanahplaza.adapter.FilterAdapter;
import com.ta.khazanahplaza.Login;
import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FilterActivity extends AppCompatActivity {

    String id, username, type;
    String nama, barcode, price, stock;
    SwipeRefreshLayout SwipeRefresh;
    EditText inputSearch;

    SharedPreferences sharedpreferences;

    ProgressDialog pDialog;
    int success;
    ConnectivityManager conMgr;

    private String url_list = Server.URL + "list_barang.php";

    private static final String TAG = FilterActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";

    public static final String TAG_ID = "id";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_TYPE = "type";
    public static final String TAG_B_ID = "b_id";
    public static final String TAG_B_NAMA = "b_nama";
    public static final String TAG_B_BARCODE = "b_barcode";
    public static final String TAG_B_HARGA = "b_harga";
    public static final String TAG_B_STOK = "b_stok";

    ListView listView;
    private List<Barang> barangItemList;
    private List<Barang> array_sort;
    CheckAdapter checkAdapter;
    int textlength = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }

        SwipeRefresh = findViewById(R.id.f_swipe_refresh);
        inputSearch = findViewById(R.id.ed_cari);

        // Mengeset properti warna yang berputar pada SwipeRefreshLayout
        SwipeRefresh.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary);

        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id = getIntent().getStringExtra(TAG_ID);
        username = getIntent().getStringExtra(TAG_USERNAME);
        type = getIntent().getStringExtra(TAG_TYPE);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Filter");
        //getSupportActionBar().setSubtitle("sairam");

        listView =  findViewById(R.id.f_lv_barang);
        barangItemList = new ArrayList<>();
        array_sort = new ArrayList<>();


        loadBarang();

        // Mengeset listener yang akan dijalankan saat layar di refresh/swipe
        SwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Handler digunakan untuk menjalankan jeda selama 5 detik


                loadBarang();
            }
        });

        checkAdapter = new CheckAdapter(barangItemList, getApplicationContext());
        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textlength = inputSearch.getText().length();
                array_sort.clear();
                for (int rec = 0; rec < barangItemList.size(); rec++) {
                    if (textlength <= barangItemList.get(rec).getNama().length()) {
                        if (barangItemList.get(rec).getNama().toLowerCase().trim().contains(
                                inputSearch.getText().toString().toLowerCase().trim())) {
                            Barang barang = new Barang(barangItemList.get(rec).getID(),
                                    barangItemList.get(rec).getNama(),
                                    barangItemList.get(rec).getBarcode(),
                                    barangItemList.get(rec).getHarga(),
                                    barangItemList.get(rec).getStok());
                            array_sort.add(barang);
                        }
                    }
                }
                FilterAdapter adapter = new FilterAdapter(array_sort, getApplicationContext());
                listView.setAdapter(adapter);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void loadBarang() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Memuat ...");
        showDialog();
        barangItemList.clear();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_list,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideDialog();
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray barangArray = obj.getJSONArray("result");

                            for (int i = 0; i < barangArray.length(); i++) {

                                JSONObject barangObject = barangArray.getJSONObject(i);


                                Barang barangItem = new Barang(barangObject.getString("id"),
                                        barangObject.getString("nama"),
                                        barangObject.getString("barcode"),
                                        barangObject.getString("harga"),
                                        barangObject.getString("stok"));

                                barangItemList.add(barangItem);
                            }

                            FilterAdapter adapter = new FilterAdapter(barangItemList, getApplicationContext());

                            listView.setAdapter(adapter);
                            // Berhenti berputar/refreshing
                            SwipeRefresh.setRefreshing(false);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        hideDialog();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}