package com.ta.khazanahplaza.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.ta.khazanahplaza.Login;
import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.app.AppController;
import com.ta.khazanahplaza.util.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TambahStok extends AppCompatActivity {

    Button btn_simpan,btn_hapus;
    EditText txt_nama, txt_barcode, txt_harga, txt_stok, ed_tmbh_stok;
    TextView txt_tmbh_stok;
    String id, username, type, b_id, b_nama, b_barcode, b_harga, b_stok;
    SharedPreferences sharedpreferences;

    ProgressDialog pDialog;
    int success;
    ConnectivityManager conMgr;
    Intent intent;

    private String url_update = Server.URL + "tambah_stok.php";

    private static final String TAG = TambahStok.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";

    public static final String TAG_ID = "id";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_TYPE = "type";
    public static final String TAG_B_ID = "b_id";
    public static final String TAG_B_NAMA = "b_nama";
    public static final String TAG_B_BARCODE = "b_barcode";
    public static final String TAG_B_HARGA = "b_harga";
    public static final String TAG_B_STOK = "b_stok";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.barang);

        //check koneksi internet
        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }

        btn_simpan = (Button) findViewById(R.id.btn_save);
        btn_hapus = (Button) findViewById(R.id.btn_delete);
        txt_nama = (EditText) findViewById(R.id.txt_name);
        txt_barcode = (EditText) findViewById(R.id.txt_barcode);
        txt_harga = (EditText) findViewById(R.id.txt_price);
        txt_stok = (EditText) findViewById(R.id.txt_stock);
        ed_tmbh_stok = (EditText) findViewById(R.id.ed_tmbh_stok);
        txt_tmbh_stok = (TextView) findViewById(R.id.txt_tmbh_stok);

        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id = getIntent().getStringExtra(TAG_ID);
        username = getIntent().getStringExtra(TAG_USERNAME);
        type = getIntent().getStringExtra(TAG_TYPE);
        b_id = getIntent().getStringExtra(TAG_B_ID);
        b_nama = getIntent().getStringExtra(TAG_B_NAMA);
        b_barcode = getIntent().getStringExtra(TAG_B_BARCODE);
        b_harga = getIntent().getStringExtra(TAG_B_HARGA);
        b_stok = getIntent().getStringExtra(TAG_B_STOK);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Tambah Stok");
        //getSupportActionBar().setSubtitle("sairam");

        ed_tmbh_stok.setVisibility(View.VISIBLE);
        txt_tmbh_stok.setVisibility(View.VISIBLE);

        //disable barcode field
        txt_barcode.setEnabled(false);
        txt_nama.setEnabled(false);
        txt_harga.setEnabled(false);
        txt_stok.setEnabled(false);
        btn_hapus.setVisibility(View.GONE);

        //set value
        txt_nama.setText(b_nama);
        txt_barcode.setText(b_barcode);
        txt_harga.setText(b_harga);
        txt_stok.setText(b_stok);

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String stok = ed_tmbh_stok.getText().toString();

                if (conMgr.getActiveNetworkInfo() != null
                        && conMgr.getActiveNetworkInfo().isAvailable()
                        && conMgr.getActiveNetworkInfo().isConnected()) {
                    updateBarang(b_id, stok);
                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void updateBarang(final String b_id, final String stok) {
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Memperbarui ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url_update, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Add Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1) {

                        Log.e("Successfully Updated!", jObj.toString());

                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                        //kembali ke menu barang
                        intent = new Intent(TambahStok.this, FilterActivity.class);
                        intent.putExtra(TAG_ID, id);
                        intent.putExtra(TAG_USERNAME, username);
                        intent.putExtra(TAG_TYPE, type);
                        finish();
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", b_id);
                params.put("stok", stok);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
