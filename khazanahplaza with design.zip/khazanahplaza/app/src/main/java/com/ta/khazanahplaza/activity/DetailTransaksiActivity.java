package com.ta.khazanahplaza.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.ta.khazanahplaza.Login;
import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.app.AppController;
import com.ta.khazanahplaza.util.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetailTransaksiActivity extends AppCompatActivity {

    Button btn_confirm;
    TextView txt_nama, txt_kios, txt_id, txt_tgl, txt_status, txt_photo;
    ImageView img;
    String id, username, type, h_id, h_nama, h_kios, h_tanggal, h_status, h_photo, confirm;
    SharedPreferences sharedpreferences;

    public static final String TAG_ID = "id";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_TYPE = "type";
    public static final String TAG_H_ID = "id_h";
    public static final String TAG_H_NAMA = "nama";
    public static final String TAG_H_KIOS = "kios";
    public static final String TAG_H_TANGGAL = "tgl";
    public static final String TAG_H_STATUS = "status";
    public static final String TAG_H_PHOTO = "photo";
    public static final String TAG_CONFIRM = "confirm";

    ProgressDialog pDialog;
    int success;
    ConnectivityManager conMgr;
    Intent intent;

    private String url_update = Server.URL + "confirm.php";

    private static final String TAG = DetailTransaksiActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_transaksi);

        //check koneksi internet
        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }

        //action bar set back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //set title
        getSupportActionBar().setTitle("Detail Sewa");
        //getSupportActionBar().setSubtitle("sairam");

        txt_id = findViewById(R.id.txt_h_idT);
        txt_nama = findViewById(R.id.txt_h_nama);
        txt_kios = findViewById(R.id.txt_h_kios);
        txt_tgl = findViewById(R.id.txt_h_tgl);
        txt_status = findViewById(R.id.txt_h_ket);
        img = findViewById(R.id.img);
        btn_confirm = findViewById(R.id.btn_confirm);

        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id = getIntent().getStringExtra(TAG_ID);
        username = getIntent().getStringExtra(TAG_USERNAME);
        type = getIntent().getStringExtra(TAG_TYPE);
        h_id = getIntent().getStringExtra(TAG_H_ID);
        h_kios = getIntent().getStringExtra(TAG_H_KIOS);
        h_nama = getIntent().getStringExtra(TAG_H_NAMA);
        h_photo = getIntent().getStringExtra(TAG_H_PHOTO);
        h_status = getIntent().getStringExtra(TAG_H_STATUS);
        h_tanggal = getIntent().getStringExtra(TAG_H_TANGGAL);
        confirm = getIntent().getStringExtra(TAG_CONFIRM);

        if (type.equals("Admin") && h_status.equals("N") && confirm.equals("Y")){
            btn_confirm.setVisibility(View.VISIBLE);
        }else{
            btn_confirm.setVisibility(View.GONE);
        }

        txt_id.setText(h_id);
        txt_kios.setText(h_kios);
        txt_nama.setText(h_nama);
        txt_tgl.setText(h_tanggal);
        if (h_status.equals("N")){
            txt_status.setText("Belum Lunas");
        }else{
            txt_status.setText("Lunas");
        }

        //url = Server.URL +"images/index.php?img="+ h_photo;

        Glide.with(this)
                .load(Server.URL+h_photo)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        // Log the GlideException here (locally or with a remote logging framework):
                        Log.e(TAG, "Load failed", e);

                        // You can also log the individual causes:
                        for (Throwable t : e.getRootCauses()) {
                            Log.e(TAG, "Caused by", t);
                        }
                        // Or, to log all root causes locally, you can use the built in helper method:
                        e.logRootCauses(TAG);

                        return false; // Allow calling onLoadFailed on the Target.
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                }).into(img);

        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (conMgr.getActiveNetworkInfo() != null
                        && conMgr.getActiveNetworkInfo().isAvailable()
                        && conMgr.getActiveNetworkInfo().isConnected()) {
                    konfirmasi(h_id);
                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void konfirmasi(final String idT) {
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Memperbarui ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url_update, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Add Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1) {

                        Log.e("Successfully Updated!", jObj.toString());

                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                        //kembali ke menu barang
                        intent = new Intent(DetailTransaksiActivity.this, KonfirmasiActivity.class);
                        intent.putExtra(TAG_ID, id);
                        intent.putExtra(TAG_USERNAME, username);
                        intent.putExtra(TAG_TYPE, type);
                        finish();
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", idT);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}