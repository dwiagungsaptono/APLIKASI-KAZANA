package com.ta.khazanahplaza.model;

import java.io.Serializable;

public class Transaksi implements Serializable {

    String id, id_user, nama, kios, tanggal, status, photo;

    public Transaksi(String id, String id_user, String kios, String nama, String tanggal, String status, String photo ) {
        this.id = id;
        this.nama = nama;
        this.id_user = id_user;
        this.kios = kios;
        this.tanggal = tanggal;
        this.status = status;
        this.photo = photo;
    }

    public String getID() {
        return id;
    }

    public String getId_user() {
        return id_user;
    }

    public String getNama() {
        return nama;
    }

    public String getKios() {
        return kios;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getStatus() {
        return status;
    }

    public String getPhoto() {
        return photo;
    }
}
