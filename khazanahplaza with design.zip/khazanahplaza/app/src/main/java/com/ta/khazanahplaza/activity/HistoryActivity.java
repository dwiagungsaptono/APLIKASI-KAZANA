package com.ta.khazanahplaza.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ta.khazanahplaza.Login;
import com.ta.khazanahplaza.R;
import com.ta.khazanahplaza.model.Transaksi;
import com.ta.khazanahplaza.adapter.TransaksiAdapter;
import com.ta.khazanahplaza.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryActivity extends AppCompatActivity {

    String id, username, type;
    String nama, barcode, price, stock;
    SwipeRefreshLayout SwipeRefresh;
    EditText inputSearch;

    SharedPreferences sharedpreferences;

    ProgressDialog pDialog;
    int success;
    ConnectivityManager conMgr;

    private String url_list = Server.URL + "list_sewa.php";
    private String url_list_all = Server.URL + "list_alltransaksi.php";

    private static final String TAG = HistoryActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";

    public static final String TAG_ID = "id";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_TYPE = "type";
    public static final String TAG_H_ID = "id_h";
    public static final String TAG_H_NAMA = "nama";
    public static final String TAG_H_KIOS = "kios";
    public static final String TAG_H_TANGGAL = "tgl";
    public static final String TAG_H_STATUS = "status";
    public static final String TAG_H_PHOTO = "photo";
    public static final String TAG_CONFIRM = "confirm";

    ListView listView;
    private List<Transaksi> transaksiItemList;
    private List<Transaksi> array_sort;
    TransaksiAdapter transaksiAdapter;
    int textlength = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }

        SwipeRefresh = findViewById(R.id.h_swipe_refresh);
        inputSearch = findViewById(R.id.ed_cari);

        // Mengeset properti warna yang berputar pada SwipeRefreshLayout
        SwipeRefresh.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary);

        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id = getIntent().getStringExtra(TAG_ID);
        username = getIntent().getStringExtra(TAG_USERNAME);
        type = getIntent().getStringExtra(TAG_TYPE);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("History Pembayaran");
        //getSupportActionBar().setSubtitle("sairam");

        listView =  findViewById(R.id.h_lv_transaksi);
        transaksiItemList = new ArrayList<>();
        array_sort = new ArrayList<>();


        loadTransaksi();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), transaksiItemList.get(i).getID(), Toast.LENGTH_SHORT).show();
                //memanggil activity update
                Intent intent = new Intent(HistoryActivity.this, DetailTransaksiActivity.class);
                intent.putExtra(TAG_ID, id);
                intent.putExtra(TAG_USERNAME, username);
                intent.putExtra(TAG_TYPE, type);
                intent.putExtra(TAG_H_ID, transaksiItemList.get(i).getID());
                intent.putExtra(TAG_H_NAMA, transaksiItemList.get(i).getNama());
                intent.putExtra(TAG_H_KIOS, transaksiItemList.get(i).getKios());
                intent.putExtra(TAG_H_TANGGAL, transaksiItemList.get(i).getTanggal());
                intent.putExtra(TAG_H_STATUS, transaksiItemList.get(i).getStatus());
                intent.putExtra(TAG_H_PHOTO, transaksiItemList.get(i).getPhoto());
                intent.putExtra(TAG_CONFIRM, "N");
                //finish();
                startActivity(intent);
            }
        });

        // Mengeset listener yang akan dijalankan saat layar di refresh/swipe
        SwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                loadTransaksi();
            }
        });

        transaksiAdapter = new TransaksiAdapter(transaksiItemList, getApplicationContext());
        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textlength = inputSearch.getText().length();
                array_sort.clear();
                for (int rec = 0; rec < transaksiItemList.size(); rec++) {
                    if (textlength <= transaksiItemList.get(rec).getTanggal().length()) {
                        if (transaksiItemList.get(rec).getTanggal().toLowerCase().trim().contains(
                                inputSearch.getText().toString().toLowerCase().trim())) {
                            Transaksi transaksi = new Transaksi(transaksiItemList.get(rec).getID(),
                                    transaksiItemList.get(rec).getId_user(),
                                    transaksiItemList.get(rec).getKios(),
                                    transaksiItemList.get(rec).getNama(),
                                    transaksiItemList.get(rec).getTanggal(),
                                    transaksiItemList.get(rec).getStatus(),
                                    transaksiItemList.get(rec).getPhoto());
                            array_sort.add(transaksi);
                        }
                    }
                }
                TransaksiAdapter adapter = new TransaksiAdapter(array_sort, getApplicationContext());
                listView.setAdapter(adapter);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    private void loadTransaksi() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Memuat ...");
        showDialog();
        transaksiItemList.clear();

        if (type.equals("Admin")) {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url_list_all,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            hideDialog();
                            try {
                                JSONObject obj = new JSONObject(response);
                                JSONArray barangArray = obj.getJSONArray("result");

                                for (int i = 0; i < barangArray.length(); i++) {

                                    JSONObject barangObject = barangArray.getJSONObject(i);


                                    Transaksi transaksiItem = new Transaksi(barangObject.getString("id"),
                                            barangObject.getString("id_user"),
                                            barangObject.getString("kios"),
                                            barangObject.getString("nama"),
                                            barangObject.getString("tanggal"),
                                            barangObject.getString("status"),
                                            barangObject.getString("photo"));

                                    transaksiItemList.add(transaksiItem);
                                }

                                TransaksiAdapter adapter = new TransaksiAdapter(transaksiItemList, getApplicationContext());

                                listView.setAdapter(adapter);
                                // Berhenti berputar/refreshing
                                SwipeRefresh.setRefreshing(false);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                            hideDialog();
                        }
                    }){

                @Override
                protected Map<String, String> getParams() {
                    // Posting parameters to login url
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("id", id);

                    return params;
                }

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        }else{
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url_list,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            hideDialog();
                            try {
                                JSONObject obj = new JSONObject(response);
                                JSONArray barangArray = obj.getJSONArray("result");

                                for (int i = 0; i < barangArray.length(); i++) {

                                    JSONObject barangObject = barangArray.getJSONObject(i);


                                    Transaksi transaksiItem = new Transaksi(barangObject.getString("id"),
                                            barangObject.getString("id_user"),
                                            barangObject.getString("kios"),
                                            barangObject.getString("nama"),
                                            barangObject.getString("tanggal"),
                                            barangObject.getString("status"),
                                            barangObject.getString("photo"));

                                    transaksiItemList.add(transaksiItem);
                                }

                                TransaksiAdapter adapter = new TransaksiAdapter(transaksiItemList, getApplicationContext());

                                listView.setAdapter(adapter);
                                // Berhenti berputar/refreshing
                                SwipeRefresh.setRefreshing(false);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                            hideDialog();
                        }
                    }){

                @Override
                protected Map<String, String> getParams() {
                    // Posting parameters to login url
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("id", id);

                    return params;
                }

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}